// Graph_adj_array_main.cpp
void Error_Exit ( char *s );

// Graph_adj_array_tree_check.cpp
int  Tree_Check_adj_array( );

// s150000_hw02.cpp
void Read_Graph_adj_array( );

void DFS_Tree_adj_array ( 
	int     src   // source node index
);