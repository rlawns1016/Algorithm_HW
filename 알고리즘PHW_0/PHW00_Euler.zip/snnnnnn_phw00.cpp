#include <stdio.h>
#include <stdlib.h>
#include "LinkedList_ptr_L.h"


void Error_Exit(char *s);
void Find_a_Path(char **G, int N, int start, ptr_L **path, ptr_L **path_end);
void Print_Path(ptr_L *path);

ptr_L *Find_Euler(char **G, int N, int start) {
	ptr_L *path = NULL, *path_end = NULL;

	// Write your own code

	return path;
}

void Find_a_Path(char **G, int N, int start, ptr_L **path, ptr_L **path_end) {

	// Write your own code

	return;
}

int getOddDegreeNum(char **G, int N, int *start) {
	int oddDegree = 0;

	// Write your own code

	return oddDegree;
}

void Print_Path(ptr_L *path) {
	ptr_L *p;
	for (p = path; p != NULL; p = p->p) {
		printf("%d ",p->i);
	}
	printf("\n");
}