extern int     Vnum;   // number of vertices
extern vertex  *V;     // vertex structure array (starting index 0)
extern int     Enum;   // number of edges
extern edge    *E;     // edge structure array (starting index 0)
extern int     cost;   // accumulated tree cost

extern int    Tree_cost;   // cost of DFS tree

extern int     Used_Memory_for_array;