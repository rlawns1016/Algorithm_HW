int     Vnum = 0;   // number of vertices
vertex  *V = NULL;  // vertex structure array (starting index 0)
int     Enum = 0;   // number of edges
edge    *E = NULL;  // edge structure array (starting index 0)
int     cost = 0;   // accumulated tree cost

int    Tree_cost = 0;   // cost of DFS tree

int     Used_Memory_for_array = 0;